editBox "Performance check" "Enter distance, count pairs:" "Perf::params"
performanceCheck $Perf::params