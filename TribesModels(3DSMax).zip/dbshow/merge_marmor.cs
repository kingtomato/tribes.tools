view ( "dts\\marmor_root.DTS" );

importSequence ( "dts\\marmor_run.DTS", 0 );
importSequence ( "dts\\marmor_run back.DTS", 0 );
importSequence ( "dts\\marmor_side left.DTS", 0 );
importSequence ( "dts\\marmor_apc root.DTS", 0 );
importSequence ( "dts\\marmor_apc pilot.DTS", 0 );

importSequence ( "dts\\marmor_pda access.DTS", 0 );
importSequence ( "dts\\marmor_sign retreat.DTS", 0 );
importSequence ( "dts\\marmor_sign over here.DTS", 0 );
importSequence ( "dts\\marmor_sign point.DTS", 0 );
importSequence ( "dts\\marmor_sign stop.DTS", 0 );
importSequence ( "dts\\marmor_salute.DTS", 0 );
importSequence ( "dts\\marmor_taunt bird.DTS", 0 );
importSequence ( "dts\\marmor_taunt know.DTS", 0 );

importSequence ( "dts\\marmor_pose kneel.DTS", 0 );
importSequence ( "dts\\marmor_pose stand.DTS", 0 );

importSequence ( "dts\\marmor_cel flip.DTS", 0 );
importSequence ( "dts\\marmor_cel rocky.DTS", 0 );
importSequence ( "dts\\marmor_cel disco.DTS", 0 );

importSequence ( "dts\\marmor_wave.DTS", 0 );


importSequence ( "dts\\marmor_die head.DTS", 0 );
importSequence ( "dts\\marmor_die chest.DTS", 0 );
importSequence ( "dts\\marmor_die left.DTS", 0 );
importSequence ( "dts\\marmor_die right.DTS", 0 );
importSequence ( "dts\\marmor_die blown back.DTS", 0 );
importSequence ( "dts\\marmor_die back.DTS", 0 );
importSequence ( "dts\\marmor_die leg right.DTS", 0 );
importSequence ( "dts\\marmor_die leg left.DTS", 0 );
importSequence ( "dts\\marmor_die spin.DTS", 0 );
importSequence ( "dts\\marmor_die grab back.DTS", 0 );
importSequence ( "dts\\marmor_die forward kneel.DTS", 0 );
importSequence ( "dts\\marmor_die forward.DTS", 0 );

importSequence ( "dts\\marmor_jet.DTS", 0 );
importSequence ( "dts\\marmor_landing.DTS", 0 );
importSequence ( "dts\\marmor_jump run.DTS", 0 );
importSequence ( "dts\\marmor_fall controlled.DTS", 0 );
importSequence ( "dts\\marmor_looks.DTS", 0 );
importSequence ( "dts\\marmor_throw.DTS", 0 );

saveShape ( "dts\\marmor.DTS" );
