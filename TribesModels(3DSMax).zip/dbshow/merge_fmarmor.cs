view ( "dts\\fmarmor_root.DTS" );

importSequence ( "dts\\fmarmor_looks.DTS", 0 );

importSequence ( "dts\\fmarmor_apc_root.DTS", 0 );
importSequence ( "dts\\fmarmor_apc_pilot.DTS", 0 );

importSequence ( "dts\\fmarmor_pose_stand.DTS", 0 );
importSequence ( "dts\\fmarmor_pose_kneel.DTS", 0 );

importSequence ( "dts\\fmarmor_pdaaccess.DTS", 0 );

importSequence ( "dts\\fmarmor_taunt_1.DTS", 0 );
importSequence ( "dts\\fmarmor_taunt_2.DTS", 0 );

importSequence ( "dts\\fmarmor_celebration_1.DTS", 0 );
importSequence ( "dts\\fmarmor_celebration_2.DTS", 0 );
importSequence ( "dts\\fmarmor_celebration_3.DTS", 0 );

importSequence ( "dts\\fmarmor_sign_point.DTS", 0 );
importSequence ( "dts\\fmarmor_sign_overhere.DTS", 0 );
importSequence ( "dts\\fmarmor_sign_retreat.DTS", 0 );
importSequence ( "dts\\fmarmor_sign_salut.DTS", 0 );
importSequence ( "dts\\fmarmor_sign_stop.DTS", 0 );

importSequence ( "dts\\fmarmor_wave.DTS", 0 );

importSequence ( "dts\\fmarmor_run.DTS", 0 );
importSequence ( "dts\\fmarmor_runback.DTS", 0 );
importSequence ( "dts\\fmarmor_sideleft.DTS", 0 );
importSequence ( "dts\\fmarmor_jumprun.DTS", 0 );

importSequence ( "dts\\fmarmor_fall.DTS", 0 );
importSequence ( "dts\\fmarmor_fall.DTS", 1 );

importSequence ( "dts\\fmarmor_jet.DTS", 0 );

importSequence ( "dts\\fmarmor_dieback.DTS", 0 );
importSequence ( "dts\\fmarmor_dieblownbck.DTS", 0 );
importSequence ( "dts\\fmarmor_diechest.DTS", 0 );


importSequence ( "dts\\fmarmor_diespin.DTS", 0 );
importSequence ( "dts\\fmarmor_dielegright.DTS", 0 );
importSequence ( "dts\\fmarmor_dielegleft.DTS", 0 );
importSequence ( "dts\\fmarmor_diehead.DTS", 0 );
importSequence ( "dts\\fmarmor_dieright.DTS", 0 );
importSequence ( "dts\\fmarmor_dieleft.DTS", 0 );
importSequence ( "dts\\fmarmor_diegrabback.DTS", 0 );
importSequence ( "dts\\fmarmor_dieforwardkneel.DTS", 0 );
importSequence ( "dts\\fmarmor_dieforward.DTS", 0 );



saveShape ( "dts\\mfemale.DTS" );
