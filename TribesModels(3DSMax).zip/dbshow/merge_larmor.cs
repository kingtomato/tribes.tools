view ( "dts\\larmor_root.DTS" );

importSequence ( "dts\\larmor_run.DTS", 0 );
importSequence ( "dts\\larmor_runback.DTS", 0 );
importSequence ( "dts\\larmor_sidelft.DTS", 0 );
importSequence ( "dts\\larmor_looks.DTS", 0 );
importSequence ( "dts\\larmor_apc_root.DTS", 0 );
importSequence ( "dts\\larmor_apc_pilot.DTS", 0 );

importSequence ( "dts\\larmor_crouch_root.DTS", 0 );
importSequence ( "dts\\larmor_crouch_looks.DTS", 0 );
importSequence ( "dts\\larmor_crouch_forward.DTS", 0 );
importSequence ( "dts\\larmor_crouch_sidelft.DTS", 0 );
importSequence ( "dts\\larmor_crouch_die.DTS", 0 );

importSequence ( "dts\\larmor_jumprun.DTS", 0 );
importSequence ( "dts\\larmor_fall.DTS", 0 );
importSequence ( "dts\\larmor_fall.DTS", 1 );
importSequence ( "dts\\larmor_jet.DTS", 0 );

importSequence ( "dts\\larmor_die_back.DTS", 0 );
importSequence ( "dts\\larmor_die_blastbck.DTS", 0 );
importSequence ( "dts\\larmor_die_chest.DTS", 0 );
importSequence ( "dts\\larmor_die_head.DTS", 0 );
importSequence ( "dts\\larmor_die_legr.DTS", 0 );
importSequence ( "dts\\larmor_die_legl.DTS", 0 );
importSequence ( "dts\\larmor_die_leftside.DTS", 0 );
importSequence ( "dts\\larmor_die_graback.DTS", 0 );
importSequence ( "dts\\larmor_die_rightside.DTS", 0 );
importSequence ( "dts\\larmor_die_spin.DTS", 0 );
importSequence ( "dts\\larmor_die_forwardkneel.DTS", 0 );
importSequence ( "dts\\larmor_die_forward.DTS", 0 );

importSequence ( "dts\\larmor_sign_overhere.DTS", 0 );
importSequence ( "dts\\larmor_sign_stop.DTS", 0 );
importSequence ( "dts\\larmor_sign_point.DTS", 0 );
importSequence ( "dts\\larmor_sign_salut.DTS", 0 );
importSequence ( "dts\\larmor_sign_retreat.DTS", 0 );

importSequence ( "dts\\larmor_pda.DTS", 0 );

importSequence ( "dts\\larmor_cel1.DTS", 0 );
importSequence ( "dts\\larmor_cel2.DTS", 0 );
importSequence ( "dts\\larmor_cel3.DTS", 0 );

importSequence ( "dts\\larmor_taunt1.DTS", 0 );
importSequence ( "dts\\larmor_taunt2.DTS", 0 );
importSequence ( "dts\\larmor_wave.DTS", 0 );

importSequence ( "dts\\larmor_flyer_root.DTS", 0 );
importSequence ( "dts\\larmor_wave.DTS", 0 );
importSequence ( "dts\\larmor_pose_kneel.DTS", 0 );
importSequence ( "dts\\larmor_pose_stand.DTS", 0 );

saveShape ( "dts\\larmor.DTS" );
