view ( "dts\\harmor_root.DTS" );

importSequence ( "dts\\harmor_run.DTS", 0 );
importSequence ( "dts\\harmor_runback.DTS", 0 );
importSequence ( "dts\\harmor_sidelft.DTS", 0 );
importSequence ( "dts\\harmor_looks.DTS", 0 );

importSequence ( "dts\\harmor_jumpstd.DTS", 0 );
importSequence ( "dts\\harmor_jumprun.DTS", 0 );
importSequence ( "dts\\harmor_fall.DTS", 0 );
importSequence ( "dts\\harmor_fall.DTS", 1 );
importSequence ( "dts\\harmor_jet.DTS", 0 );

importSequence ( "dts\\harmor_die_back.DTS", 0 );
importSequence ( "dts\\harmor_die_blastbck.DTS", 0 );
importSequence ( "dts\\harmor_die_chest.DTS", 0 );
importSequence ( "dts\\harmor_die_head.DTS", 0 );
importSequence ( "dts\\harmor_die_legr.DTS", 0 );
importSequence ( "dts\\harmor_die_legl.DTS", 0 );
importSequence ( "dts\\harmor_die_lft.DTS", 0 );
importSequence ( "dts\\harmor_die_grabback.DTS", 0 );
importSequence ( "dts\\harmor_die_rgt.DTS", 0 );
importSequence ( "dts\\harmor_die_spin.DTS", 0 );
importSequence ( "dts\\harmor_die_fwdkn.DTS", 0 );
importSequence ( "dts\\harmor_die_forward.DTS", 0 );

importSequence ( "dts\\harmor_sign_overhere.DTS", 0 );
importSequence ( "dts\\harmor_sign_stop.DTS", 0 );
importSequence ( "dts\\harmor_sign_point.DTS", 0 );
importSequence ( "dts\\harmor_sign_salut.DTS", 0 );
importSequence ( "dts\\harmor_wave.DTS", 0 );


importSequence ( "dts\\harmor_pdaaccess.DTS", 0 );

importSequence ( "dts\\harmor_celebration1.DTS", 0 );
importSequence ( "dts\\harmor_celebration2.DTS", 0 );
importSequence ( "dts\\harmor_celebration3.DTS", 0 );

importSequence ( "dts\\harmor_taunt1.DTS", 0 );
importSequence ( "dts\\harmor_taunt2.DTS", 0 );

importSequence ( "dts\\harmor_pose_kneel.DTS", 0 );
importSequence ( "dts\\harmor_pose_stand.DTS", 0 );

saveShape ( "dts\\harmor.DTS" );
