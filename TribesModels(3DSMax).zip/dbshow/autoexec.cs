$ArtPath = "art\\";
$AllowMultipleShapes = "True";
$PaletteName = "show2.ppl";

lighton ();

