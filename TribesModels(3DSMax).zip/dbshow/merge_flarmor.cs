view ( "dts\\lfarmor_root.DTS" );

importSequence ( "dts\\lfarmor_run.DTS", 0 );
importSequence ( "dts\\lfarmor_run back.DTS", 0 );
importSequence ( "dts\\lfarmor_side left.DTS", 0 );
importSequence ( "dts\\lfarmor_jet.DTS", 0 );
importSequence ( "dts\\lfarmor_fall.DTS", 0 );
importSequence ( "dts\\lfarmor_landing.DTS", 0 );
importSequence ( "dts\\lfarmor_jump run.DTS", 0 );
importSequence ( "dts\\lfarmor_looks.DTS", 0 );
importSequence ( "dts\\lfarmor_pda access.DTS", 0 );
importSequence ( "dts\\lfarmor_flyer_root.DTS", 0 );
importSequence ( "dts\\lfarmor_apc root.DTS", 0 );

importSequence ( "dts\\lfarmor_cel dance.DTS", 0 );
importSequence ( "dts\\lfarmor_cel flex.DTS", 0 );
importSequence ( "dts\\lfarmor_cel high five.DTS", 0 );

importSequence ( "dts\\lfarmor_taunt butt.DTS", 0 );
importSequence ( "dts\\lfarmor_taunt impatient.DTS", 0 );
importSequence ( "dts\\lfarmor_wave.DTS", 0 );

importSequence ( "dts\\lfarmor_pose kneel.DTS", 0 );
importSequence ( "dts\\lfarmor_pose stand.DTS", 0 );

importSequence ( "dts\\lfarmor_crouch.DTS", 0 );
importSequence ( "dts\\lfarmor_crouch looks.DTS", 0 );
importSequence ( "dts\\lfarmor_crouch forward.DTS", 0 );
importSequence ( "dts\\lfarmor_crouch left.DTS", 0 );
importSequence ( "dts\\lfarmor_crouch die.DTS", 0 );

importSequence ( "dts\\lfarmor_die forward.DTS", 0 );
importSequence ( "dts\\lfarmor_die chest.DTS", 0 );
importSequence ( "dts\\lfarmor_die back.DTS", 0 );
importSequence ( "dts\\lfarmor_die blown back.DTS", 0 );
importSequence ( "dts\\lfarmor_die spin.DTS", 0 );
importSequence ( "dts\\lfarmor_die head.DTS", 0 );
importSequence ( "dts\\lfarmor_die left side.DTS", 0 );
importSequence ( "dts\\lfarmor_die right side.DTS", 0 );
importSequence ( "dts\\lfarmor_die leg right.DTS", 0 );
importSequence ( "dts\\lfarmor_die forward kneel.DTS", 0 );
importSequence ( "dts\\lfarmor_die leg left.DTS", 0 );
importSequence ( "dts\\lfarmor_die grab back.DTS", 0 );

importSequence ( "dts\\lfarmor_sign over here.DTS", 0 );
importSequence ( "dts\\lfarmor_sign point.DTS", 0 );
importSequence ( "dts\\lfarmor_sign retreat.DTS", 0 );
importSequence ( "dts\\lfarmor_sign salut.DTS", 0 );
importSequence ( "dts\\lfarmor_sign stop.DTS", 0 );




saveShape ( "dts\\lfemale.DTS" );
