function speed1()
{
	$DirectionalVelocity = 0.01;
    $PositiveRotation = 0.2; 
    $NegativeRotation = -0.2;
}
function speed2()
{
	$DirectionalVelocity =  0.05;
    $PositiveRotation = 0.5;
    $NegativeRotation =  -0.5;
}
function speed3()
{
	$DirectionalVelocity =  0.1;
    $PositiveRotation = 1.0;
    $NegativeRotation =  -1.0;
}
function speed4()
{
	$DirectionalVelocity =  0.2;
    $PositiveRotation = 2.0;
    $NegativeRotation =  -2.0;
}
function speed5()
{
	$DirectionalVelocity =  0.5;
    $PositiveRotation = 3.0;
    $NegativeRotation =  -3.0;
}
function speed6()
{
	$DirectionalVelocity =  1;
    $PositiveRotation = 4.0;
    $NegativeRotation =  -4.0;
}
function speed7()
{
	$DirectionalVelocity =  4;
    $PositiveRotation = 6.0;
    $NegativeRotation =  -6.0;
}
function speed8()
{
	$DirectionalVelocity =  10;
    $PositiveRotation = 8.0;
    $NegativeRotation =  -8.0;
}
function speed9()
{
	$DirectionalVelocity =  15;
    $PositiveRotation = 15.0;
    $NegativeRotation =  -15.0;
}
function speed0()
{
	$DirectionalVelocity =  20;
    $PositiveRotation = 30.0;
    $NegativeRotation =  -30.0;
}

speed3();




// bind( keyboard, make, o, to, "postAction( showCam, MoveBackward, $DirectionalVelocity );" );
// bind( keyboard, make, o, to, "postAction( showCam, MoveBackward, 0 );" );
// bind( keyboard, make, p, to, "postAction( showCam, MoveForward, $DirectionalVelocity );" );
// bind( keyboard, make, p, to, "postAction( showCam, MoveForward, 0 );" );


// bind( keyboard, make, s, to, "postAction( $ActionTarget, IDACTION_MOVELEFT, 0 );" );
// bind( keyboard, make, f, to, "postAction( $ActionTarget, MoveRight, $DirectionalVelocity );" );
// bind( keyboard, make, f, to, "postAction( $ActionTarget, MoveRight, 0 );" );
// bind( keyboard, make, d, to, "postAction( $ActionTarget, MoveBackward, $DirectionalVelocity );" );
// bind( keyboard, make, d, to, "postAction( $ActionTarget, MoveBackward, 0 );" );
// bind( keyboard, make, e, to, "postAction( $ActionTarget, MoveForward, $DirectionalVelocity );" );
// bind( keyboard, make, e, to, "postAction( $ActionTarget, MoveForward, 0 );" );
// bind( keyboard, make, r, to, "postAction( $ActionTarget, MoveUp, $DirectionalVelocity );" );
// bind( keyboard, make, r, to, "postAction( $ActionTarget, MoveUp, 0 );" );
// bind( keyboard, make, v, to, "postAction( $ActionTarget, MoveDown, $DirectionalVelocity );" );
// bind( keyboard, make, v, to, "postAction( $ActionTarget, MoveDown, 0 );" );
// bind( keyboard, make, j, to, "postAction( $ActionTarget, ViewYaw, $PositiveRotation );" );
// bind( keyboard, make, j, to, "postAction( $ActionTarget, ViewYaw, 0 );" );
// bind( keyboard, make, l, to, "postAction( $ActionTarget, ViewYaw, $NegativeRotation );" );
// bind( keyboard, make, l, to, "postAction( $ActionTarget, ViewYaw, 0 );" );
// bind( keyboard, make, i, to, "postAction( $ActionTarget, ViewPitch, $NegativeRotation );" );
// bind( keyboard, make, i, to, "postAction( $ActionTarget, ViewPitch, 0 );" );
// bind( keyboard, make, k, to, "postAction( $ActionTarget, ViewPitch, $PositiveRotation );" );
// bind( keyboard, make, k, to, "postAction( $ActionTarget, ViewPitch, 0 );" );
// bind( keyboard, make, y, to, "postAction( $ActionTarget, ViewRoll, $NegativeRotation );" );
// bind( keyboard, make, y, to, "postAction( $ActionTarget, ViewRoll, 0 );" );
// bind( keyboard, make, u, to, "postAction( $ActionTarget, ViewRoll, $PositiveRotation );" );
// bind( keyboard, make, u, to, "postAction( $ActionTarget, ViewRoll, 0 );" );

// bind( keyboard, make, tab, to, "next();" );
// bind( keyboard, make, x, to, "detach();" );
